﻿using System;
using System.Collections.Generic;

namespace EntityFrameworkCore.Data.ScaffoldModels;

public partial class TeamsCoachesLeague
{
    public string? Name { get; set; }

    public string? CoachName { get; set; }

    public string? LeagueName { get; set; }
}
