﻿// See https://aka.ms/new-console-template for more information
using EntityFrameworkCore.Data;

Console.WriteLine("Hello, World!");

using var db = new FootballLeageDbContext();
