﻿namespace EntityFrameworkCore.Api.Models
{
    public class LeagueDto
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}