﻿namespace EntityFrameworkCore.Api.Models
{
    public class CoachDto
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}
