/*
	Adding more teams 
	Change date() to GetDate() for SQL server
*/

insert into teams(name, CreatedDate) 
values 
('Chelsea F.C.',date()),
('Real Madrid',date()),
('Benfica',date()),
('Inter Milan',date()),
('Inter Miami',date()),
('Seba United',date())