﻿namespace EntityFrameworkCore.Domain;

public abstract class BaseDomainModel
{
    public DateTime CreatedDate { get; set; }
}

